  <script>
    // Auto-close flash after 5s
    document.querySelectorAll('.flash').forEach(el=>{
      setTimeout(()=>{ el.style.opacity='0'; setTimeout(()=>el.remove(), 400); }, 5000);
    });
    // Format currency input
    document.querySelectorAll('input[data-money]').forEach(inp=>{
      const fmt = v => {
        v = String(v||'').replace(/[^\d]/g,'');
        if(!v) return '';
        return v.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
      };
      inp.value = fmt(inp.value);
      inp.addEventListener('input', e => { e.target.value = fmt(e.target.value); });
    });
  </script>
</body>
</html>
