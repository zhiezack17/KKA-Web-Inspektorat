<?php
class PrintController {
    private Auth $auth;
    public function __construct(Auth $auth) { $this->auth = $auth; $auth->require(); }

    public function sesi(): void {
        $id = (int) input('id');
        $sesi = DB::one('
            SELECT s.*, d.nama AS desa_nama, k.nama AS kecamatan_nama,
                   b.nama AS bidang_nama, sb.nama AS sub_bidang_nama
            FROM kka_sesi s
            JOIN kka_desa d ON d.id = s.desa_id
            JOIN kka_kecamatan k ON k.id = d.kecamatan_id
            JOIN kka_bidang b ON b.id = s.bidang_id
            LEFT JOIN kka_sub_bidang sb ON sb.id = s.sub_bidang_id
            WHERE s.id = ?', [$id]);
        if (!$sesi) { http_response_code(404); exit('Sesi tidak ditemukan'); }
        $rincian = DB::all('SELECT * FROM kka_rincian WHERE sesi_id = ? ORDER BY urutan, id', [$id]);
        $totals = [
            'pagu'      => (float) $sesi['pagu_anggaran'],
            'dikwitansi'=> array_sum(array_column($rincian, 'biaya_dikwitansi')),
            'realisasi' => array_sum(array_column($rincian, 'realisasi')),
        ];
        $totals['selisih'] = $totals['dikwitansi'] - $totals['realisasi'];
        view('print/sesi', compact('sesi','rincian','totals'));
    }

    public function exportExcel(): void {
        $id = (int) input('id');
        $sesi = DB::one('
            SELECT s.*, d.nama AS desa_nama, k.nama AS kecamatan_nama,
                   b.nama AS bidang_nama, sb.nama AS sub_bidang_nama
            FROM kka_sesi s
            JOIN kka_desa d ON d.id = s.desa_id
            JOIN kka_kecamatan k ON k.id = d.kecamatan_id
            JOIN kka_bidang b ON b.id = s.bidang_id
            LEFT JOIN kka_sub_bidang sb ON sb.id = s.sub_bidang_id
            WHERE s.id = ?', [$id]);
        if (!$sesi) { http_response_code(404); exit('Sesi tidak ditemukan'); }
        $rincian = DB::all('SELECT * FROM kka_rincian WHERE sesi_id = ? ORDER BY urutan, id', [$id]);

        $filename = 'KKA_' . preg_replace('/[^A-Za-z0-9]/', '_', $sesi['desa_nama']) . '_S' . $sesi['semester'] . '_' . $sesi['tahun_anggaran'] . '.xls';
        $this->outputExcelHeader($filename);
        $this->renderSesiExcel($sesi, $rincian);
        exit;
    }

    public function exportRekap(): void {
        $tahun = (int) input('tahun', 0);
        $desaId = (int) input('desa', 0);
        $where = '1=1'; $p = [];
        if ($tahun > 0) { $where .= ' AND s.tahun_anggaran = ?'; $p[] = $tahun; }
        if ($desaId > 0){ $where .= ' AND s.desa_id = ?'; $p[] = $desaId; }
        $rows = DB::all("
            SELECT d.nama AS desa, k.nama AS kecamatan, s.tahun_anggaran,
                   SUM(s.pagu_anggaran) AS pagu,
                   COALESCE(SUM(rinc.dikwitansi_sesi),0) AS dikwitansi,
                   COALESCE(SUM(rinc.realisasi_sesi),0) AS realisasi,
                   COUNT(DISTINCT s.id) AS jumlah_sesi
            FROM kka_sesi s
            JOIN kka_desa d ON d.id = s.desa_id
            JOIN kka_kecamatan k ON k.id = d.kecamatan_id
            LEFT JOIN (
                SELECT sesi_id,
                       SUM(biaya_dikwitansi) AS dikwitansi_sesi,
                       SUM(realisasi) AS realisasi_sesi
                FROM kka_rincian
                GROUP BY sesi_id
            ) rinc ON rinc.sesi_id = s.id
            WHERE $where
            GROUP BY d.id, d.nama, k.nama, s.tahun_anggaran
            ORDER BY s.tahun_anggaran DESC, d.nama ASC
        ", $p);
        $filename = 'Rekap_KKA_' . ($tahun ?: 'semua') . '_' . date('Ymd_His') . '.xls';
        $this->outputExcelHeader($filename);
        $this->renderRekapExcel($rows);
        exit;
    }

    private function outputExcelHeader(string $filename): void {
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        header('Expires: 0');
        echo "\xEF\xBB\xBF"; // BOM UTF-8 agar excel baca akurat
    }

    private function renderSesiExcel(array $s, array $rincian): void {
        // Pakai HTML table — Excel akan membaca dengan format yang benar
        echo '<html><head><meta charset="utf-8"></head><body>';
        echo '<h2>KERTAS KERJA AUDIT (KKA)</h2>';
        echo '<h3>PENGELUARAN KEUANGAN KEPENGHULUAN</h3>';
        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;font-family:Arial">';
        $rows = [
            'Kepenghuluan / Desa' => $s['desa_nama'] . ' (Kec. ' . $s['kecamatan_nama'] . ')',
            'Bidang'              => $s['bidang_nama'],
            'Sub Bidang'          => $s['sub_bidang_nama'] ?: '-',
            'Masa Audit'          => 'Semester ' . $s['semester'] . ' Tahun ' . $s['tahun_anggaran'],
            'Kegiatan'            => $s['kegiatan'] ?: '-',
            'Pagu Anggaran'       => 'Rp ' . number_format((float)$s['pagu_anggaran'],0,',','.'),
            'No. KKA'             => $s['no_kka'] ?: '-',
            'Ref. KKA'            => $s['ref_kka'] ?: '-',
            'Auditor'             => $s['dibuat_oleh'] ?: '-',
            'Tanggal Dibuat'      => tgl_id($s['tanggal_dibuat']),
            'Direview Oleh (Ketua Tim)' => $s['direview_oleh'] ?: '-',
            'Tanggal Review'      => tgl_id($s['tanggal_review']),
            'Diketahui Oleh (Dalnis)'  => $s['dievaluasi_oleh'] ?: '-',
            'Tanggal Diketahui'    => tgl_id($s['tanggal_evaluasi']),
        ];
        foreach ($rows as $k => $v) {
            echo '<tr><th align="left" style="background:#f0f0f0">' . e($k) . '</th><td>' . e($v) . '</td></tr>';
        }
        echo '</table><br><br>';

        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;font-family:Arial">';
        echo '<thead><tr style="background:#10b981;color:white">
                <th>No</th><th>Uraian / Rincian Belanja</th>
                <th>Biaya Dikwitansi (Rp)</th><th>Realisasi (Rp)</th><th>Selisih (Rp)</th>
                <th>Penerima</th><th>Keterangan</th>
              </tr></thead><tbody>';
        $tk=$tr=$ts=0; $no=1;
        foreach ($rincian as $r) {
            $sel = (float)$r['biaya_dikwitansi'] - (float)$r['realisasi'];
            $tk += (float)$r['biaya_dikwitansi'];
            $tr += (float)$r['realisasi']; $ts += $sel;
            echo '<tr>
                <td align="center">' . ($no++) . '</td>
                <td>' . e($r['uraian']) . '</td>
                <td align="right">' . number_format($r['biaya_dikwitansi'],0,',','.') . '</td>
                <td align="right">' . number_format($r['realisasi'],0,',','.') . '</td>
                <td align="right">' . number_format($sel,0,',','.') . '</td>
                <td>' . e($r['penerima'] ?: '-') . '</td>
                <td>' . e($r['keterangan'] ?: '-') . '</td>
              </tr>';
        }
        echo '<tr style="background:#f0f0f0;font-weight:bold">
                <td colspan="2" align="center">JUMLAH (Pagu: Rp ' . number_format((float)$s['pagu_anggaran'],0,',','.') . ')</td>
                <td align="right">' . number_format($tk,0,',','.') . '</td>
                <td align="right">' . number_format($tr,0,',','.') . '</td>
                <td align="right">' . number_format($ts,0,',','.') . '</td>
                <td colspan="2"></td>
              </tr>';
        echo '</tbody></table><br><br>';

        echo '<p><b>KESIMPULAN AUDIT:</b><br>' . nl2br(e($s['kesimpulan'] ?: '-')) . '</p>';
        echo '<p><b>SUMBER DATA:</b><br>' . nl2br(e($s['sumber_data'] ?: '-')) . '</p>';
        echo '</body></html>';
    }

    private function renderRekapExcel(array $rows): void {
        echo '<html><head><meta charset="utf-8"></head><body>';
        echo '<h2>REKAP KERTAS KERJA AUDIT - PER DESA</h2>';
        echo '<table border="1" cellpadding="6" style="border-collapse:collapse;font-family:Arial">';
        echo '<thead><tr style="background:#10b981;color:white">
                <th>No</th><th>Desa / Kepenghuluan</th><th>Kecamatan</th><th>Tahun</th>
                <th>Jumlah Sesi</th><th>Pagu (Rp)</th><th>Dikwitansi (Rp)</th><th>Realisasi (Rp)</th><th>Selisih (Rp)</th>
              </tr></thead><tbody>';
        $tp=$tk=$tr=$ts=0; $no=1;
        foreach ($rows as $r) {
            $sel = (float)$r['dikwitansi'] - (float)$r['realisasi'];
            $tp += (float)$r['pagu']; $tk += (float)$r['dikwitansi'];
            $tr += (float)$r['realisasi']; $ts += $sel;
            echo '<tr>
                <td align="center">' . ($no++) . '</td>
                <td>' . e($r['desa']) . '</td>
                <td>' . e($r['kecamatan']) . '</td>
                <td align="center">' . (int)$r['tahun_anggaran'] . '</td>
                <td align="center">' . (int)$r['jumlah_sesi'] . '</td>
                <td align="right">' . number_format($r['pagu'],0,',','.') . '</td>
                <td align="right">' . number_format($r['dikwitansi'],0,',','.') . '</td>
                <td align="right">' . number_format($r['realisasi'],0,',','.') . '</td>
                <td align="right">' . number_format($sel,0,',','.') . '</td>
              </tr>';
        }
        echo '<tr style="background:#f0f0f0;font-weight:bold">
                <td colspan="5" align="center">JUMLAH</td>
                <td align="right">' . number_format($tp,0,',','.') . '</td>
                <td align="right">' . number_format($tk,0,',','.') . '</td>
                <td align="right">' . number_format($tr,0,',','.') . '</td>
                <td align="right">' . number_format($ts,0,',','.') . '</td>
              </tr>';
        echo '</tbody></table></body></html>';
    }
}
