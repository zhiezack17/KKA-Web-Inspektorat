<?php
class DashboardController {
    private Auth $auth;
    public function __construct(Auth $auth) { $this->auth = $auth; $auth->require(); }

    public function index(): void {
        $stats = [
            'desa'    => (int) DB::scalar('SELECT COUNT(*) FROM kka_desa'),
            'kec'     => (int) DB::scalar('SELECT COUNT(*) FROM kka_kecamatan'),
            'sesi'    => (int) DB::scalar('SELECT COUNT(*) FROM kka_sesi'),
            'sesi_ty' => (int) DB::scalar('SELECT COUNT(*) FROM kka_sesi WHERE tahun_anggaran = ?', [(int)date('Y')]),
            'anggaran'=> (float) DB::scalar('SELECT COALESCE(SUM(pagu_anggaran),0) FROM kka_sesi'),
            'dikwitansi'=>(float) DB::scalar('SELECT COALESCE(SUM(biaya_dikwitansi),0) FROM kka_rincian'),
            'realisasi'=>(float) DB::scalar('SELECT COALESCE(SUM(realisasi),0) FROM kka_rincian'),
        ];
        $stats['selisih'] = $stats['dikwitansi'] - $stats['realisasi'];

        $recent = DB::all('
            SELECT s.id, s.objek_audit, s.semester, s.tahun_anggaran, s.no_kka, s.tanggal_dibuat,
                   d.nama AS desa, b.nama AS bidang
            FROM kka_sesi s
            JOIN kka_desa d ON d.id = s.desa_id
            JOIN kka_bidang b ON b.id = s.bidang_id
            ORDER BY s.created_at DESC
            LIMIT 6
        ');

        $perBidang = DB::all('
            SELECT b.nama, COUNT(s.id) AS jumlah
            FROM kka_bidang b
            LEFT JOIN kka_sesi s ON s.bidang_id = b.id
            GROUP BY b.id, b.nama ORDER BY b.urutan
        ');

        view('dashboard/index', compact('stats','recent','perBidang'));
    }
}
