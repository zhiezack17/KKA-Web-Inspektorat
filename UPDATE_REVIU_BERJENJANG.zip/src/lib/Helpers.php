<?php
/**
 * Helper umum.
 */

function e(?string $s): string {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function url(string $path = ''): string {
    $base = rtrim($GLOBALS['app_base_url'] ?? '', '/');
    if ($path === '') return $base . '/';
    if (str_starts_with($path, '/')) return $base . $path;
    return $base . '/' . $path;
}

function asset(string $path): string {
    return url('assets/' . ltrim($path, '/'));
}

function redirect(string $path): void {
    header('Location: ' . url($path));
    exit;
}

function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}

function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    $token = $_POST['_csrf'] ?? '';
    if (!hash_equals(csrf_token(), (string)$token)) {
        http_response_code(419);
        exit('CSRF token tidak valid. Silakan refresh halaman.');
    }
}

function flash(string $type, string $msg): void {
    $_SESSION['_flash'][] = ['type' => $type, 'msg' => $msg];
}

function flash_pull(): array {
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}

function rupiah($val, bool $withSymbol = true): string {
    $val = (float)$val;
    $out = number_format($val, 0, ',', '.');
    return $withSymbol ? 'Rp ' . $out : $out;
}

function parse_money($v): float {
    // Hanya nilai numeric asli (int/float dari kode) yang boleh langsung dicast.
    // String seperti "800.000" is_numeric()==true tapi maksudnya 800 ribu, bukan 800.
    if (is_int($v) || is_float($v)) return (float)$v;
    $v = preg_replace('/[^\d,.\-]/', '', (string)$v);
    // hilangkan separator ribuan (titik) lalu ganti koma jadi titik
    $v = str_replace('.', '', $v);
    $v = str_replace(',', '.', $v);
    return $v === '' ? 0 : (float)$v;
}

function tgl_id(?string $date): string {
    if (!$date) return '-';
    $ts = strtotime($date);
    if (!$ts) return '-';
    $bulan = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return date('j', $ts) . ' ' . $bulan[(int)date('n', $ts)] . ' ' . date('Y', $ts);
}

function view(string $tpl, array $data = []): void {
    $cfg = $GLOBALS['cfg'];
    $auth = $GLOBALS['auth'] ?? null;
    extract($data, EXTR_SKIP);
    $file = $cfg['root_dir'] . '/src/views/' . $tpl . '.php';
    if (!is_file($file)) {
        http_response_code(500);
        exit('Template tidak ditemukan: ' . e($tpl));
    }
    require $file;
}

function partial(string $tpl, array $data = []): void {
    view('partials/' . $tpl, $data);
}

function only_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        exit('Method not allowed');
    }
}

function input(string $key, $default = null) {
    $v = $_POST[$key] ?? $_GET[$key] ?? $default;
    if (is_string($v)) $v = trim($v);
    return $v;
}

function kka_status_info(?string $status): array {
    $st = strtoupper((string)($status ?: 'DRAFT'));
    switch ($st) {
        case 'REVIEW_KETUA':
            return [
                'code'  => 'REVIEW_KETUA',
                'label' => 'Reviu Ketua Tim',
                'bg'    => '#fef3c7',
                'color' => '#b45309',
                'border'=> '#fde68a',
                'icon'  => 'fa-solid fa-user-clock',
                'desc'  => 'Sedang ditelaah dan diverifikasi oleh Ketua Tim',
            ];
        case 'REVIEW_DALNIS':
            return [
                'code'  => 'REVIEW_DALNIS',
                'label' => 'Reviu Dalnis',
                'bg'    => '#e0e7ff',
                'color' => '#4338ca',
                'border'=> '#c7d2fe',
                'icon'  => 'fa-solid fa-user-check',
                'desc'  => 'Menunggu persetujuan & pengesahan Pengendali Teknis',
            ];
        case 'PERLU_REVISI':
            return [
                'code'  => 'PERLU_REVISI',
                'label' => 'Perlu Revisi',
                'bg'    => '#fee2e2',
                'color' => '#b91c1c',
                'border'=> '#fecaca',
                'icon'  => 'fa-solid fa-triangle-exclamation',
                'desc'  => 'KKA dikembalikan dengan catatan perbaikan',
            ];
        case 'SELESAI_FINAL':
            return [
                'code'  => 'SELESAI_FINAL',
                'label' => 'Sah / Disetujui',
                'bg'    => '#dcfce7',
                'color' => '#15803d',
                'border'=> '#bbf7d0',
                'icon'  => 'fa-solid fa-circle-check',
                'desc'  => 'KKA telah disetujui & disahkan oleh Pengendali Teknis',
            ];
        case 'DRAFT':
        default:
            return [
                'code'  => 'DRAFT',
                'label' => 'Draft',
                'bg'    => '#f1f5f9',
                'color' => '#475569',
                'border'=> '#cbd5e1',
                'icon'  => 'fa-solid fa-file-pen',
                'desc'  => 'Masih dalam proses penyusunan oleh Auditor',
            ];
    }
}

function kka_status_badge(?string $status, bool $withIcon = true): string {
    $info = kka_status_info($status);
    $ico = $withIcon ? '<i class="' . $info['icon'] . '" style="margin-right:5px"></i>' : '';
    return '<span style="display:inline-flex;align-items:center;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:700;line-height:1.2;background:' . $info['bg'] . ';color:' . $info['color'] . ';border:1px solid ' . $info['border'] . '">' . $ico . e($info['label']) . '</span>';
}

/**
 * ==========================================================
 * Isolasi data antar-pengguna (data ownership).
 * Admin melihat SEMUA data; auditor melihat data
 * miliknya sendiri (kolom kka_sesi.created_by), sesi di mana
 * ia ditunjuk sebagai Ketua Tim atau Dalnis, atau yang dibagikan.
 * ==========================================================
 */

/**
 * Fragmen WHERE untuk membatasi query pada data milik user (kecuali admin).
 * Termasuk sesi di mana user menjadi Ketua Tim, Dalnis, atau dishare.
 * $col adalah kolom created_by pada tabel kka_sesi ber-alias (mis. "s.created_by").
 */
function owner_where($auth, string $col = 's.created_by'): array {
    if ($auth && $auth->isAdmin()) return ['', []];
    $uid = $auth ? (int) $auth->id() : 0;
    $alias = strpos($col, '.') !== false ? substr($col, 0, strpos($col, '.')) : $col;
    return [
        " AND ($col = ? OR $alias.ketua_tim_id = ? OR $alias.dalnis_id = ? OR $alias.id IN (SELECT sesi_id FROM kka_sesi_share WHERE user_id = ?))",
        [$uid, $uid, $uid, $uid],
    ];
}

/**
 * True jika user boleh mengakses sesi (admin, pembuat, ketua tim, dalnis, ATAU penerima berbagi).
 * $sesi harus memuat 'created_by' dan salah satu dari 'sesi_id' atau 'id'
 * (id sesi). Bila keduanya ada, 'sesi_id' diutamakan agar aman untuk baris
 * hasil JOIN (mis. lampiran yang punya id sendiri).
 */
function sesi_is_owned($auth, ?array $sesi): bool {
    if (!$sesi || !$auth) return false;
    if ($auth->isAdmin()) return true;
    $uid = (int) $auth->id();
    if ((int) ($sesi['created_by'] ?? 0) === $uid) return true;
    if ((int) ($sesi['ketua_tim_id'] ?? 0) === $uid) return true;
    if ((int) ($sesi['dalnis_id'] ?? 0) === $uid) return true;
    $sid = (int) ($sesi['sesi_id'] ?? $sesi['id'] ?? 0);
    if ($sid > 0) {
        return (bool) DB::scalar(
            'SELECT 1 FROM kka_sesi_share WHERE sesi_id = ? AND user_id = ? LIMIT 1',
            [$sid, $uid]
        );
    }
    return false;
}

/** Hentikan akses (redirect) bila sesi tidak ada atau bukan milik user. */
function guard_sesi($auth, ?array $sesi, string $redirectTo = 'sesi'): void {
    if (!$sesi) {
        flash('error', 'Sesi audit tidak ditemukan.');
        redirect($redirectTo);
    }
    if (!sesi_is_owned($auth, $sesi)) {
        http_response_code(403);
        flash('error', 'Anda tidak memiliki akses ke data audit ini.');
        redirect($redirectTo);
    }
}
