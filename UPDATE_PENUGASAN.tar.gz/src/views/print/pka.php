<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Program Kerja Audit (PKA) — <?= e($pka['no_pka']) ?></title>
  <style>
    @page {
      size: 330mm 215mm; /* Standar Folio Landscape / Lanskap */
      margin: 12mm 15mm 12mm 15mm;
    }
    * { box-sizing: border-box; }
    body {
      font-family: "Times New Roman", Times, serif;
      font-size: 10pt;
      line-height: 1.3;
      color: #000;
      background: #fff;
      margin: 0;
      padding: 0;
    }
    .no-print {
      background: #f8fafc;
      border-bottom: 1px solid #cbd5e1;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .btn-print {
      background: #0284c7;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-family: sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      border: none;
    }
    .container {
      width: 100%;
      max-width: 1100px;
      margin: 0 auto;
      padding: 10px;
    }
    .kop {
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 3px double #000;
      padding-bottom: 6px;
      margin-bottom: 10px;
    }
    .kop-logo { width: 65px; text-align: center; }
    .kop-logo img { width: 60px; height: auto; }
    .kop-text { flex: 1; text-align: center; }
    .kop-text h2 { margin: 0; font-size: 12pt; font-weight: bold; letter-spacing: 0.5px; text-transform: uppercase; }
    .kop-text h1 { margin: 1px 0; font-size: 15pt; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
    .kop-text p { margin: 0; font-size: 8pt; line-height: 1.2; }

    .doc-title {
      text-align: center;
      font-size: 12pt;
      font-weight: bold;
      text-decoration: underline;
      text-transform: uppercase;
      margin: 6px 0 2px;
      letter-spacing: 0.5px;
    }
    .doc-sub {
      text-align: center;
      font-size: 9.5pt;
      margin-bottom: 10px;
    }

    table.meta-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 8px;
      font-size: 9.5pt;
    }
    table.meta-table td {
      padding: 2px 4px;
      vertical-align: top;
    }

    table.grid-table {
      width: 100%;
      border-collapse: collapse;
      margin: 8px 0;
      font-size: 9pt;
    }
    table.grid-table th, table.grid-table td {
      border: 1px solid #000;
      padding: 4px 6px;
      vertical-align: top;
    }
    table.grid-table th {
      background-color: #f1f5f9;
      text-align: center;
      font-weight: bold;
    }

    table.ttd-table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 14px;
      font-size: 9.5pt;
      page-break-inside: avoid;
    }
    table.ttd-table td {
      vertical-align: top;
      text-align: center;
      padding: 0 10px;
    }

    @media print {
      .no-print { display: none !important; }
      body { margin: 0; background: #fff; }
      .container { padding: 0; width: 100%; max-width: 100%; }
    }
  </style>
</head>
<body>

<div class="no-print">
  <div style="font-family:sans-serif;font-size:13px;color:#475569">
    <b>Preview Cetak:</b> Program Kerja Audit (PKA) Standar APIP — Matriks Pembagian Tugas Anggota 1 &amp; 2
  </div>
  <button class="btn-print" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
</div>

<div class="container">
  <!-- KOP SURAT -->
  <div class="kop">
    <div class="kop-logo">
      <img src="<?= asset('img/logo-rohil.png') ?>" alt="Logo Rokan Hilir">
    </div>
    <div class="kop-text">
      <h2>PEMERINTAH KABUPATEN ROKAN HILIR</h2>
      <h1>INSPEKTORAT</h1>
      <p>Komplek Perkantoran Batu 6 Jl. Lintas Pesisir Sungai Rokan, Kec. Bangko - Bagansiapiapi &middot; Telp. (0767) 2700270</p>
    </div>
  </div>

  <div class="doc-title">PROGRAM KERJA AUDIT (PKA)</div>
  <div class="doc-sub">Nomor PKA : <?= e($pka['no_pka']) ?></div>

  <!-- IDENTITAS PENUGASAN -->
  <table class="meta-table">
    <tr>
      <td style="width:160px"><b>Obyek Pemeriksaan</b></td>
      <td style="width:10px">:</td>
      <td style="width:350px"><b>Kepenghuluan <?= e($pka['desa_nama']) ?></b> (Kec. <?= e($pka['kecamatan_nama']) ?>)</td>
      <td style="width:160px"><b>Nomor / Tanggal SPT</b></td>
      <td style="width:10px">:</td>
      <td><?= e($pka['no_spt']) ?> / <?= tgl_id($pka['tgl_spt']) ?></td>
    </tr>
    <tr>
      <td><b>Tahun Anggaran Diaudit</b></td>
      <td>:</td>
      <td>Tahun Anggaran <?= (int)$pka['tahun_anggaran'] ?></td>
      <td><b>Jangka Waktu Tugas</b></td>
      <td>:</td>
      <td><?= tgl_id($pka['tgl_mulai']) ?> s.d <?= tgl_id($pka['tgl_selesai']) ?> (<?= (int)$pka['lama_hari'] ?> Hari)</td>
    </tr>
  </table>

  <!-- MATRIKS PROSEDUR AUDIT & PEMBAGIAN PELAKSANA -->
  <table class="grid-table">
    <thead>
      <tr>
        <th style="width:30px">No</th>
        <th style="width:22%">Ruang Lingkup / Bidang</th>
        <th style="width:34%">Uraian Prosedur Pengujian</th>
        <th style="width:18%">Pelaksana Audit (Anggota Tim)</th>
        <th style="width:6%">Rencana (Jam)</th>
        <th style="width:10%">No. Ref KKA</th>
        <th style="width:10%">Status</th>
      </tr>
    </thead>
    <tbody>
      <?php $no = 1; foreach ($langkah as $l): ?>
        <tr>
          <td align="center"><b><?= $no++ ?></b></td>
          <td>
            <b><?= e($l['bidang_nama']) ?></b>
            <?php if (!empty($l['tujuan_pengujian'])): ?>
              <div style="font-size:8pt;color:#334155;margin-top:2px"><i>Tujuan: <?= e($l['tujuan_pengujian']) ?></i></div>
            <?php endif; ?>
          </td>
          <td><?= e($l['uraian_prosedur']) ?></td>
          <td>
            <b><?= e($l['pelaksana_nama'] ?: 'Ketua Tim & Anggota') ?></b>
          </td>
          <td align="center"><?= (int)$l['waktu_rencana_jam'] ?></td>
          <td align="center"><b><?= e($l['ref_kka_nomor'] ?: '-') ?></b></td>
          <td align="center">
            <?php if ($l['status_pelaksanaan'] === 'SELESAI'): ?>
              <span style="font-weight:bold;color:#047857">&#10004; Selesai</span>
            <?php elseif ($l['status_pelaksanaan'] === 'SEDANG'): ?>
              <span style="color:#d97706">Berjalan</span>
            <?php else: ?>
              <span style="color:#64748b">Rencana</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- TIGA KOLOM TANDA TANGAN BERJENJANG (KETUA TIM, DALNIS, IRBAN) -->
  <table class="ttd-table">
    <tr>
      <td style="width:33%">
        <b>Disetujui oleh:</b><br>
        Pengendali Teknis (Dalnis),
        <br><br><br><br>
        <u><b><?= e($pka['dalnis_nama']) ?></b></u><br>
        Auditor Ahli Madya
      </td>
      <td style="width:34%">
        <b>Disusun oleh:</b><br>
        Ketua Tim Pemeriksa,
        <br><br><br><br>
        <u><b><?= e($pka['ketua_tim_nama']) ?></b></u><br>
        Auditor Ahli Muda
      </td>
      <td style="width:33%">
        <b>Diketahui oleh:</b><br>
        Wakil Penanggung Jawab,
        <br><br><br><br>
        <u><b><?= e($pka['irban_nama']) ?></b></u><br>
        Inspektur Pembantu
      </td>
    </tr>
  </table>
</div>

</body>
</html>
