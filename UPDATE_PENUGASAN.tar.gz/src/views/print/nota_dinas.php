<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Nota Dinas Penugasan — <?= e($nd['no_nd']) ?></title>
  <style>
    @page {
      size: 215mm 330mm; /* Standar Folio / F4 */
      margin: 15mm 20mm 15mm 20mm;
    }
    * { box-sizing: border-box; }
    body {
      font-family: "Times New Roman", Times, serif;
      font-size: 11.5pt;
      line-height: 1.35;
      color: #000;
      background: #fff;
      margin: 0;
      padding: 0;
    }
    .no-print {
      background: #f8fafc;
      border-bottom: 1px solid #cbd5e1;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .btn-print {
      background: #0284c7;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-family: sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      border: none;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 15px 25px;
    }
    .kop {
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 3px double #000;
      padding-bottom: 8px;
      margin-bottom: 16px;
    }
    .kop-logo { width: 75px; text-align: center; }
    .kop-logo img { width: 70px; height: auto; }
    .kop-text { flex: 1; text-align: center; }
    .kop-text h2 { margin: 0; font-size: 14pt; font-weight: bold; letter-spacing: 0.5px; text-transform: uppercase; }
    .kop-text h1 { margin: 2px 0; font-size: 17pt; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
    .kop-text p { margin: 0; font-size: 8.5pt; line-height: 1.25; }

    .doc-title {
      text-align: center;
      font-size: 14pt;
      font-weight: bold;
      text-decoration: underline;
      text-transform: uppercase;
      margin: 12px 0 4px;
      letter-spacing: 1px;
    }
    .doc-sub {
      text-align: center;
      font-size: 11pt;
      margin-bottom: 16px;
    }

    table.meta-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 16px;
      font-size: 11pt;
    }
    table.meta-table td {
      padding: 3px 4px;
      vertical-align: top;
    }

    .divider {
      border-bottom: 1px solid #000;
      margin: 12px 0 16px;
    }

    .content-body {
      text-align: justify;
      line-height: 1.45;
    }
    .content-body p { margin: 0 0 10px; text-indent: 32px; }

    table.grid-table {
      width: 100%;
      border-collapse: collapse;
      margin: 12px 0;
      font-size: 10.5pt;
    }
    table.grid-table th, table.grid-table td {
      border: 1px solid #000;
      padding: 5px 8px;
      vertical-align: middle;
    }
    table.grid-table th {
      background-color: #f1f5f9;
      text-align: center;
      font-weight: bold;
    }

    .box-disposisi {
      border: 2px solid #000;
      padding: 12px 16px;
      margin-top: 24px;
      page-break-inside: avoid;
    }

    @media print {
      .no-print { display: none !important; }
      body { margin: 0; background: #fff; }
      .container { padding: 0; width: 100%; }
    }
  </style>
</head>
<body>

<div class="no-print">
  <div style="font-family:sans-serif;font-size:13px;color:#475569">
    <b>Preview Cetak:</b> Nota Dinas Pengajuan Penugasan Audit (Standar Rohil)
  </div>
  <button class="btn-print" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
</div>

<div class="container">
  <!-- KOP SURAT -->
  <div class="kop">
    <div class="kop-logo">
      <img src="<?= asset('img/logo-rohil.png') ?>" alt="Logo Rokan Hilir">
    </div>
    <div class="kop-text">
      <h2>PEMERINTAH KABUPATEN ROKAN HILIR</h2>
      <h1>INSPEKTORAT</h1>
      <p>Komplek Perkantoran Batu 6 Jl. Lintas Pesisir Sungai Rokan, Kec. Bangko - Bagansiapiapi</p>
      <p>Telp. (0767) 2700270 &middot; Email: inspektorat@rohilkab.go.id &middot; Website: inspektorat.rohilkab.go.id</p>
    </div>
  </div>

  <!-- JUDUL -->
  <div class="doc-title">NOTA DINAS</div>
  <div class="doc-sub">Nomor : <?= e($nd['no_nd']) ?></div>

  <!-- META NOTA DINAS -->
  <table class="meta-table">
    <tr>
      <td style="width:110px"><b>Kepada Yth.</b></td>
      <td style="width:10px">:</td>
      <td><b>Inspektur Daerah Kabupaten Rokan Hilir</b></td>
    </tr>
    <tr>
      <td><b>Dari</b></td>
      <td>:</td>
      <td><?= e($nd['irban_nama']) ?></td>
    </tr>
    <tr>
      <td><b>Tanggal</b></td>
      <td>:</td>
      <td><?= tgl_id($nd['tgl_nd']) ?></td>
    </tr>
    <tr>
      <td><b>Sifat</b></td>
      <td>:</td>
      <td>Penting</td>
    </tr>
    <tr>
      <td><b>Lampiran</b></td>
      <td>:</td>
      <td>1 (satu) Berkas</td>
    </tr>
    <tr>
      <td><b>Perihal</b></td>
      <td>:</td>
      <td><b>Permohonan Penerbitan Surat Perintah Tugas (SPT) Pengawasan Keuangan Kepenghuluan <?= e($nd['desa_nama']) ?> TA <?= (int)$nd['tahun_anggaran'] ?></b></td>
    </tr>
  </table>

  <div class="divider"></div>

  <!-- ISI NOTA DINAS -->
  <div class="content-body">
    <p>
      Sehubungan dengan Program Kerja Pengawasan Tahunan (PKPT) Inspektorat Kabupaten Rokan Hilir Tahun Anggaran <?= (int)$nd['tahun_anggaran'] ?>, bersama ini diajukan usulan penugasan <?= e($nd['jenis_audit']) ?> atas <b><?= e($nd['tujuan']) ?></b> pada Kepenghuluan <b><?= e($nd['desa_nama']) ?></b> Kecamatan <b><?= e($nd['kecamatan_nama']) ?></b>.
    </p>

    <p style="margin-bottom:6px">
      Pelaksanaan penugasan direncanakan selama <b><?= (int)$nd['lama_hari'] ?> (sepuluh) hari kerja</b> terhitung mulai tanggal <b><?= tgl_id($nd['tgl_mulai']) ?></b> sampai dengan tanggal <b><?= tgl_id($nd['tgl_selesai']) ?></b> dengan susunan tim pemeriksa sebagai berikut:
    </p>

    <!-- TABEL SUSUNAN TIM -->
    <table class="grid-table">
      <thead>
        <tr>
          <th style="width:35px">No</th>
          <th style="width:32%">Peran dalam Tim</th>
          <th>Nama / NIP</th>
          <th style="width:30%">Jabatan Kedinasan</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td align="center">1</td>
          <td><b>Penanggung Jawab</b></td>
          <td><b>H. SARMAN SYAHRONI, ST., M.IP</b><br><span style="font-size:9pt">NIP. 19760810 200312 1 004</span></td>
          <td>Inspektur Daerah</td>
        </tr>
        <tr>
          <td align="center">2</td>
          <td><b>Wakil Penanggung Jawab</b></td>
          <td><b><?= e($nd['irban_nama']) ?></b><br><span style="font-size:9pt">NIP. <?= e(format_nip($irbanUser['nip'] ?? '')) ?></span></td>
          <td><?= e($irbanUser['jabatan'] ?? 'Inspektur Pembantu') ?></td>
        </tr>
        <tr>
          <td align="center">3</td>
          <td><b>Pengendali Teknis (Dalnis)</b></td>
          <td><b><?= e($nd['dalnis_nama']) ?></b><br><span style="font-size:9pt">NIP. <?= e(format_nip($dalnisUser['nip'] ?? '')) ?></span></td>
          <td><?= e($dalnisUser['jabatan'] ?? 'Auditor Ahli Madya') ?></td>
        </tr>
        <tr>
          <td align="center">4</td>
          <td><b>Ketua Tim</b></td>
          <td><b><?= e($nd['ketua_tim_nama']) ?></b><br><span style="font-size:9pt">NIP. <?= e(format_nip($ketuaUser['nip'] ?? '')) ?></span></td>
          <td><?= e($ketuaUser['jabatan'] ?? 'Auditor Ahli Muda') ?></td>
        </tr>
        <?php $noAg = 5; foreach ($anggotaList as $ag): ?>
          <tr>
            <td align="center"><?= $noAg++ ?></td>
            <td><b>Anggota Tim</b></td>
            <td><b><?= e($ag['nama']) ?></b><br><span style="font-size:9pt">NIP. <?= e(format_nip($ag['nip'] ?? '')) ?></span></td>
            <td><?= e($ag['jabatan'] ?? 'Auditor') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <p>
      Demikian Nota Dinas ini kami sampaikan, mohon petunjuk, arahan, serta persetujuan Bapak Inspektur untuk penerbitan Surat Perintah Tugas (SPT) pengawasan dimaksud.
    </p>
  </div>

  <!-- TANDA TANGAN IRBAN -->
  <table style="width:100%;margin-top:20px;page-break-inside:avoid">
    <tr>
      <td style="width:55%"></td>
      <td style="text-align:center">
        <b>Pengusul Penugasan,</b><br>
        <?= e($irbanUser['jabatan'] ?? 'Inspektur Pembantu') ?>,
        <br><br><br><br>
        <u><b><?= e($nd['irban_nama']) ?></b></u><br>
        NIP. <?= e(format_nip($irbanUser['nip'] ?? '')) ?>
      </td>
    </tr>
  </table>

  <!-- LEMBAR DISPOSISI INSPEKTUR DAERAH -->
  <div class="box-disposisi">
    <div style="display:flex;justify-content:space-between;border-bottom:1.5px solid #000;padding-bottom:4px;margin-bottom:8px">
      <b style="font-size:11pt;text-transform:uppercase">DISPOSISI / PETUNJUK INSPEKTUR DAERAH:</b>
      <span style="font-size:10pt">Tanggal Disposisi: <?= !empty($nd['tgl_disposisi']) ? tgl_id($nd['tgl_disposisi']) : '....................................' ?></span>
    </div>

    <div style="display:flex;gap:24px;margin-bottom:8px;font-size:10.5pt">
      <label>
        [ <?= ($nd['status'] === 'DISETUJUI') ? '&#10004;' : '&nbsp;&nbsp;' ?> ] <b>DISETUJUI</b> (Proses Surat Perintah Tugas)
      </label>
      <label>
        [ <?= ($nd['status'] === 'DITOLAK') ? '&#10004;' : '&nbsp;&nbsp;' ?> ] <b>KEMBALIKAN KE IRBAN</b> (Perlu Perbaikan)
      </label>
    </div>

    <div style="font-size:10.5pt;line-height:1.4;margin-bottom:10px">
      <b>Catatan / Instruksi Disposisi:</b><br>
      <div style="font-style:italic;padding-left:8px;min-height:30px">
        <?= e($nd['catatan_inspektur'] ?: 'Disetujui. Teruskan ke Bagian SPT untuk penomoran dan penerbitan Surat Perintah Tugas resmi.') ?>
      </div>
    </div>

    <table style="width:100%">
      <tr>
        <td style="width:50%"></td>
        <td style="text-align:center;font-size:10.5pt">
          <b>Inspektur Daerah Kabupaten Rokan Hilir</b>
          <br><br><br><br>
          <u><b>H. SARMAN SYAHRONI, ST., M.IP</b></u><br>
          NIP. 19760810 200312 1 004
        </td>
      </tr>
    </table>
  </div>
</div>

</body>
</html>
