<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Surat Perintah Tugas — <?= e($spt['no_spt']) ?></title>
  <style>
    @page {
      size: 215mm 330mm; /* Standar Folio / F4 */
      margin: 15mm 20mm 15mm 20mm;
    }
    * { box-sizing: border-box; }
    body {
      font-family: "Times New Roman", Times, serif;
      font-size: 11pt;
      line-height: 1.35;
      color: #000;
      background: #fff;
      margin: 0;
      padding: 0;
    }
    .no-print {
      background: #f8fafc;
      border-bottom: 1px solid #cbd5e1;
      padding: 10px 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    .btn-print {
      background: #0284c7;
      color: #fff;
      padding: 8px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-family: sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      border: none;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      padding: 15px 25px;
    }
    .kop {
      display: flex;
      align-items: center;
      gap: 16px;
      border-bottom: 3px double #000;
      padding-bottom: 8px;
      margin-bottom: 14px;
    }
    .kop-logo { width: 75px; text-align: center; }
    .kop-logo img { width: 70px; height: auto; }
    .kop-text { flex: 1; text-align: center; }
    .kop-text h2 { margin: 0; font-size: 14pt; font-weight: bold; letter-spacing: 0.5px; text-transform: uppercase; }
    .kop-text h1 { margin: 2px 0; font-size: 17pt; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; }
    .kop-text p { margin: 0; font-size: 8.5pt; line-height: 1.25; }

    .doc-title {
      text-align: center;
      font-size: 13.5pt;
      font-weight: bold;
      text-decoration: underline;
      text-transform: uppercase;
      margin: 10px 0 2px;
      letter-spacing: 1px;
    }
    .doc-sub {
      text-align: center;
      font-size: 11pt;
      margin-bottom: 14px;
    }

    table.dasar-table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 12px;
      font-size: 10.5pt;
    }
    table.dasar-table td {
      padding: 2px 4px;
      vertical-align: top;
      text-align: justify;
    }

    .perintah-title {
      text-align: center;
      font-size: 11.5pt;
      font-weight: bold;
      letter-spacing: 1px;
      text-transform: uppercase;
      margin: 12px 0;
    }

    table.grid-table {
      width: 100%;
      border-collapse: collapse;
      margin: 8px 0 14px;
      font-size: 10pt;
    }
    table.grid-table th, table.grid-table td {
      border: 1px solid #000;
      padding: 4px 6px;
      vertical-align: middle;
    }
    table.grid-table th {
      background-color: #f1f5f9;
      text-align: center;
      font-weight: bold;
    }

    ol.tujuan-list {
      margin: 0;
      padding-left: 20px;
      text-align: justify;
      line-height: 1.4;
    }
    ol.tujuan-list li { margin-bottom: 4px; }

    @media print {
      .no-print { display: none !important; }
      body { margin: 0; background: #fff; }
      .container { padding: 0; width: 100%; }
    }
  </style>
</head>
<body>

<div class="no-print">
  <div style="font-family:sans-serif;font-size:13px;color:#475569">
    <b>Preview Cetak:</b> Surat Perintah Tugas (SPT) Resmi Pemkab Rokan Hilir
  </div>
  <button class="btn-print" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
</div>

<div class="container">
  <!-- KOP SURAT RESMI -->
  <div class="kop">
    <div class="kop-logo">
      <img src="<?= asset('img/logo-rohil.png') ?>" alt="Logo Rokan Hilir">
    </div>
    <div class="kop-text">
      <h2>PEMERINTAH KABUPATEN ROKAN HILIR</h2>
      <h1>INSPEKTORAT</h1>
      <p>Komplek Perkantoran Batu 6 Jl. Lintas Pesisir Sungai Rokan, Kec. Bangko - Bagansiapiapi</p>
      <p>Telp. (0767) 2700270 &middot; Email: inspektorat@rohilkab.go.id &middot; Website: inspektorat.rohilkab.go.id</p>
    </div>
  </div>

  <!-- JUDUL -->
  <div class="doc-title">SURAT PERINTAH TUGAS</div>
  <div class="doc-sub">NOMOR : <?= e($spt['no_spt']) ?></div>

  <!-- DASAR HUKUM -->
  <table class="dasar-table">
    <tr>
      <td style="width:75px"><b>Dasar</b></td>
      <td style="width:10px">:</td>
      <td>
        <div style="white-space:pre-line;line-height:1.4"><?= e($spt['dasar_hukum']) ?></div>
      </td>
    </tr>
  </table>

  <div class="perintah-title">MEMERINTAHKAN :</div>

  <table class="dasar-table" style="margin-bottom:6px">
    <tr>
      <td style="width:75px"><b>Kepada</b></td>
      <td style="width:10px">:</td>
      <td></td>
    </tr>
  </table>

  <!-- TABEL SUSUNAN TIM PEMERIKSA -->
  <table class="grid-table">
    <thead>
      <tr>
        <th style="width:30px">No</th>
        <th style="width:35%">Nama / NIP</th>
        <th style="width:30%">Pangkat / Jabatan</th>
        <th style="width:30%">Kedudukan dalam Tim</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td align="center">1</td>
        <td><b>H. SARMAN SYAHRONI, ST., M.IP</b><br><span style="font-size:8.5pt">NIP. 19760810 200312 1 004</span></td>
        <td>Pembina Utama Muda (IV/c)<br>Inspektur Daerah</td>
        <td><b>Penanggung Jawab</b></td>
      </tr>
      <tr>
        <td align="center">2</td>
        <td><b><?= e($spt['wakil_pj_nama']) ?></b></td>
        <td>Inspektur Pembantu</td>
        <td><b>Wakil Penanggung Jawab</b></td>
      </tr>
      <tr>
        <td align="center">3</td>
        <td><b><?= e($spt['dalnis_nama']) ?></b></td>
        <td>Auditor Ahli Madya</td>
        <td><b>Pengendali Teknis (Dalnis)</b></td>
      </tr>
      <tr>
        <td align="center">4</td>
        <td><b><?= e($spt['ketua_tim_nama']) ?></b></td>
        <td>Auditor Ahli Muda</td>
        <td><b>Ketua Tim</b></td>
      </tr>
      <?php $noAg = 5; foreach ($anggotaList as $ag): ?>
        <tr>
          <td align="center"><?= $noAg++ ?></td>
          <td><b><?= e($ag['nama']) ?></b><br><span style="font-size:8.5pt">NIP. <?= e(format_nip($ag['nip'] ?? '')) ?></span></td>
          <td><?= e($ag['jabatan'] ?? 'Auditor') ?></td>
          <td><b>Anggota Tim</b></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- UNTUK -->
  <table class="dasar-table">
    <tr>
      <td style="width:75px"><b>Untuk</b></td>
      <td style="width:10px">:</td>
      <td>
        <ol class="tujuan-list">
          <li>
            Melaksanakan <b><?= e($spt['tujuan']) ?></b> pada Kepenghuluan <b><?= e($spt['desa_nama']) ?></b> Kecamatan <b><?= e($spt['kecamatan_nama']) ?></b> Kabupaten Rokan Hilir Tahun Anggaran <?= (int)$spt['tahun_anggaran'] ?>;
          </li>
          <li>
            Tugas dilaksanakan selama <b><?= (int)$spt['lama_hari'] ?> (sepuluh) hari kerja</b> terhitung mulai tanggal <b><?= tgl_id($spt['tgl_mulai']) ?></b> sampai dengan tanggal <b><?= tgl_id($spt['tgl_selesai']) ?></b>;
          </li>
          <li>
            Melaporkan hasil pelaksanaan tugas dalam bentuk Laporan Hasil Audit (LHA) kepada Inspektur Daerah Kabupaten Rokan Hilir;
          </li>
          <li>
            Melaksanakan perintah ini dengan penuh tanggung jawab dan mempedomani Standar Audit Aparat Pengawasan Intern Pemerintah (APIP).
          </li>
        </ol>
      </td>
    </tr>
  </table>

  <!-- TANDA TANGAN INSPEKTUR DAERAH -->
  <table style="width:100%;margin-top:20px;page-break-inside:avoid">
    <tr>
      <td style="width:50%"></td>
      <td style="text-align:center;font-size:11pt">
        Ditetapkan di : Bagansiapiapi<br>
        Pada tanggal &nbsp;: <?= tgl_id($spt['tgl_spt']) ?><br>
        <div style="border-bottom:1px solid #000;margin:6px 0"></div>
        <b>INSPEKTUR DAERAH KABUPATEN ROKAN HILIR</b>
        <br><br><br><br><br>
        <u><b>H. SARMAN SYAHRONI, ST., M.IP</b></u><br>
        Pembina Utama Muda (IV/c)<br>
        NIP. 19760810 200312 1 004
      </td>
    </tr>
  </table>

  <!-- TEMBUSAN -->
  <div style="font-size:9.5pt;margin-top:14px;page-break-inside:avoid">
    <b><u>Tembusan disampaikan kepada Yth:</u></b>
    <ol style="margin:2px 0 0;padding-left:18px">
      <li>Bupati Rokan Hilir (sebagai laporan);</li>
      <li>Sekretaris Daerah Kabupaten Rokan Hilir;</li>
      <li>Camat <?= e($spt['kecamatan_nama']) ?>;</li>
      <li>Penjabat Penghulu <?= e($spt['desa_nama']) ?>;</li>
      <li>Arsip.</li>
    </ol>
  </div>
</div>

</body>
</html>
