<?php
$auth = $GLOBALS['auth'];
$user = $auth->user();
$current = $_SERVER['REQUEST_URI'] ?? '';
function nav_active($needle, $current) {
    return str_contains($current, $needle) ? ' active' : '';
}

// Cek jumlah antrean disposisi jika Inspektur login
$badgeDisposisi = 0;
if ($auth->isInspektur()) {
    $badgeDisposisi = (int) DB::val("SELECT COUNT(*) FROM kka_nota_dinas WHERE status = 'DIAJUKAN_INSPEKTUR'");
}
?>
<aside class="sidebar" data-testid="sidebar">
  <div class="brand">
    <div class="brand-logo">
      <img src="<?= asset('img/logo-rohil.png') ?>" alt="Rohil">
    </div>
    <div class="brand-text">
      <h1>KKA DIGITAL</h1>
      <p>Inspektorat Rokan Hilir</p>
    </div>

    <button class="sidebar-close" id="sidebarCloseBtn" aria-label="Tutup menu">
      <i class="fa-solid fa-xmark"></i>
    </button>
  </div>

  <nav class="nav">
    <a href="<?= url('dashboard') ?>" class="nav-item<?= nav_active('/dashboard', $current) ?>" data-testid="nav-dashboard">
      <i class="fa-solid fa-gauge"></i><span>Dashboard</span>
    </a>

    <div class="nav-section">Pra-Audit &amp; Penugasan</div>
    <a href="<?= url('penugasan/nota-dinas') ?>" class="nav-item<?= nav_active('/penugasan/nota-dinas', $current) ?>" data-testid="nav-nota-dinas">
      <i class="fa-solid fa-envelope-open-text"></i><span>Nota Dinas (ND)</span>
      <?php if ($badgeDisposisi > 0): ?>
        <span class="badge" style="background:#ef4444;color:#fff;font-size:10px;padding:2px 6px;border-radius:10px;margin-left:auto"><?= $badgeDisposisi ?></span>
      <?php endif; ?>
    </a>
    <a href="<?= url('penugasan/spt') ?>" class="nav-item<?= nav_active('/penugasan/spt', $current) ?>" data-testid="nav-spt">
      <i class="fa-solid fa-file-signature"></i><span>Surat Tugas (SPT)</span>
    </a>
    <a href="<?= url('penugasan/pka') ?>" class="nav-item<?= nav_active('/penugasan/pka', $current) ?>" data-testid="nav-pka">
      <i class="fa-solid fa-list-check"></i><span>Matriks PKA</span>
    </a>

    <div class="nav-section">Pelaksanaan Audit</div>
    <a href="<?= url('sesi') ?>" class="nav-item<?= nav_active('/sesi', $current) ?>" data-testid="nav-sesi">
      <i class="fa-solid fa-clipboard-list"></i><span>Kertas Kerja (KKA)</span>
    </a>
    <a href="<?= url('rekap') ?>" class="nav-item<?= nav_active('/rekap', $current) ?>" data-testid="nav-rekap">
      <i class="fa-solid fa-chart-column"></i><span>Rekap Belanja</span>
    </a>
    <a href="<?= url('master') ?>" class="nav-item<?= nav_active('/master', $current) ?>" data-testid="nav-master">
      <i class="fa-solid fa-folder-tree"></i><span>Master KKA</span>
    </a>

    <div class="nav-section">Panduan &amp; Pengaturan</div>
    <a href="<?= url('panduan-workflow') ?>" class="nav-item<?= nav_active('/panduan-workflow', $current) ?>" data-testid="nav-workflow">
      <i class="fa-solid fa-diagram-project"></i><span>SOP &amp; Workflow</span>
    </a>
    <a href="<?= url('desa') ?>" class="nav-item<?= nav_active('/desa', $current) ?>" data-testid="nav-desa">
      <i class="fa-solid fa-building-columns"></i><span>Manajemen Desa</span>
    </a>
    <?php if ($auth->isAdmin()): ?>
      <a href="<?= url('users') ?>" class="nav-item<?= nav_active('/users', $current) ?>" data-testid="nav-users">
        <i class="fa-solid fa-users-gear"></i><span>Manajemen Pengguna</span>
      </a>
    <?php endif; ?>
  </nav>

  <div class="sidebar-foot">
    <a href="<?= url('profile') ?>" class="userbox" data-testid="userbox">
      <div class="avatar"><?= e(strtoupper(mb_substr($user['nama'] ?? 'U', 0, 1))) ?></div>
      <div class="info">
        <div class="name"><?= e($user['nama']) ?></div>
        <div class="email" style="font-size:11px;color:#cbd5e1;text-transform:capitalize"><?= e($user['role']) ?> &bull; <?= e(mb_substr($user['jabatan'] ?? '', 0, 24)) ?></div>
      </div>
    </a>
    <a class="logout" href="<?= url('logout') ?>" data-testid="logout-btn">
      <i class="fa-solid fa-right-from-bracket"></i> Keluar
    </a>
  </div>
</aside>