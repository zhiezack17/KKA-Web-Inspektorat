<?php view('partials/head', ['title' => 'Matriks PKA & Pembagian Tugas Anggota — KKA Digital']); ?>
<div class="layout">
  <?php view('partials/sidebar'); ?>
  <main class="main">
    <div class="topbar">
      <div class="topbar-left">
        <a href="<?= url('penugasan/pka') ?>" class="btn btn-outline btn-sm" style="margin-right:12px">
          <i class="fa-solid fa-arrow-left"></i> Kembali
        </a>
        <div>
          <h2 class="page-title">Matriks Program Kerja Audit (PKA)</h2>
          <p class="page-sub">Pembagian ruang lingkup prosedur pengujian untuk Anggota 1 &amp; Anggota 2</p>
        </div>
      </div>
      <div class="topbar-right">
        <a href="<?= url('print/pka?id=' . $pka['id']) ?>" target="_blank" class="btn btn-outline" data-testid="btn-print-pka">
          <i class="fa-solid fa-print"></i> Cetak PKA Resmi
        </a>
      </div>
    </div>

    <div class="content">
      <?php view('partials/flash'); ?>

      <!-- HEADER PENUGASAN -->
      <div class="card" style="margin-bottom:16px;background:linear-gradient(to right, #f8fafc, #f1f5f9)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:14px">
          <div>
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px">
              <span class="badge badge-primary"><?= e($pka['no_pka']) ?></span>
              <span style="font-size:13px;color:#64748b">Tanggal: <?= tgl_id($pka['tgl_pka']) ?></span>
            </div>
            <h3 style="margin:0 0 4px;font-size:17px;font-weight:700;color:#0f172a">
              Pemeriksaan Kepenghuluan <?= e($pka['desa_nama']) ?> (Kec. <?= e($pka['kecamatan_nama']) ?>)
            </h3>
            <div style="font-size:12.5px;color:#475569">
              <b>Dasar SPT:</b> <?= e($pka['no_spt']) ?> (<?= tgl_id($pka['tgl_mulai']) ?> s.d <?= tgl_id($pka['tgl_selesai']) ?> &bull; <?= (int)$pka['lama_hari'] ?> Hari Kerja)
            </div>
          </div>

          <div style="display:flex;gap:16px;font-size:12.5px">
            <div style="background:#fff;padding:8px 12px;border-radius:8px;border:1px solid #e2e8f0">
              <div style="color:#64748b;font-size:11px">Pengendali Teknis (Dalnis)</div>
              <div style="font-weight:700;color:#0f172a"><?= e($pka['dalnis_nama']) ?></div>
            </div>
            <div style="background:#fff;padding:8px 12px;border-radius:8px;border:1px solid #e2e8f0">
              <div style="color:#64748b;font-size:11px">Ketua Tim Pemeriksa</div>
              <div style="font-weight:700;color:#0369a1"><?= e($pka['ketua_tim_nama']) ?></div>
            </div>
          </div>
        </div>

        <!-- DAFTAR ANGGOTA TIM -->
        <div style="margin-top:14px;padding-top:10px;border-top:1px dashed #cbd5e1;display:flex;align-items:center;gap:12px;flex-wrap:wrap">
          <span style="font-size:12px;font-weight:700;color:#334155"><i class="fa-solid fa-users"></i> Anggota Tim Tersedia:</span>
          <?php $idx = 1; foreach ($anggotaList as $ag): ?>
            <span class="badge" style="background:#e0f2fe;color:#0369a1;padding:4px 8px;font-size:11.5px">
              <b>Anggota <?= $idx++ ?>:</b> <?= e($ag['nama']) ?> (<?= e($ag['jabatan']) ?>)
            </span>
          <?php endforeach; ?>
        </div>
      </div>

      <!-- KARTU APPROVAL DALNIS (JIKA DALNIS LOGIN & STATUS REVIEW_DALNIS) -->
      <?php if ($isDalnis && $pka['status'] === 'REVIEW_DALNIS'): ?>
        <div class="card" style="border:2px solid #f59e0b;background:#fffdfa;margin-bottom:16px">
          <h3 style="margin:0 0 10px;font-size:15px;font-weight:700;color:#92400e;display:flex;align-items:center;gap:8px">
            <i class="fa-solid fa-file-signature" style="color:#f59e0b"></i> Lembar Persetujuan Pengendali Teknis (Dalnis)
          </h3>
          <p style="font-size:12.5px;color:#78350f;margin:0 0 12px">
            Ketua Tim telah menyusun alokasi tugas langkah kerja audit. Silakan reviu dan berikan persetujuan.
          </p>
          <form method="POST" action="<?= url('penugasan/pka/approve') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= $pka['id'] ?>">
            <div style="margin-bottom:12px">
              <label class="form-label" style="font-weight:600">Catatan / Arahan Dalnis:</label>
              <textarea name="catatan_dalnis" class="form-control" rows="2" style="font-size:12.5px">Disetujui. Laksanakan pengujian secara seksama dan laporkan progres secara berkala.</textarea>
            </div>
            <button type="submit" class="btn btn-success">
              <i class="fa-solid fa-circle-check"></i> Setujui Program Kerja Audit (PKA)
            </button>
          </form>
        </div>
      <?php endif; ?>

      <!-- FORM MATRIKS LANGKAH KERJA AUDIT -->
      <form method="POST" action="<?= url('penugasan/pka/update') ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $pka['id'] ?>">

        <div class="card">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;border-bottom:1px solid #e2e8f0;padding-bottom:10px">
            <div>
              <h3 style="margin:0;font-size:15px;font-weight:700;color:#0f172a">
                <i class="fa-solid fa-table-list" style="color:#0284c7"></i> Matriks Alokasi Prosedur Audit ke Anggota Tim
              </h3>
              <p style="margin:2px 0 0;font-size:12px;color:#64748b">
                Ketua Tim menentukan pembagian tugas (Anggota 1, Anggota 2, atau Bersama) pada setiap bidang pengujian.
              </p>
            </div>
            <div style="display:flex;gap:8px">
              <button type="submit" name="action" value="save" class="btn btn-outline" style="font-size:12.5px">
                <i class="fa-solid fa-floppy-disk"></i> Simpan Pembagian Tugas
              </button>
              <?php if ($pka['status'] !== 'DISETUJUI'): ?>
                <button type="submit" name="action" value="ajukan" class="btn btn-primary" style="font-size:12.5px">
                  <i class="fa-solid fa-paper-plane"></i> Ajukan ke Dalnis
                </button>
              <?php endif; ?>
            </div>
          </div>

          <div class="table-responsive">
            <table class="table" style="font-size:12.5px;vertical-align:middle">
              <thead>
                <tr style="background:#f8fafc">
                  <th style="width:40px;text-align:center">No</th>
                  <th style="width:24%">Ruang Lingkup &amp; Bidang Belanja</th>
                  <th style="width:30%">Uraian Prosedur / Langkah Pengujian</th>
                  <th style="width:22%">Pelaksana Audit (Anggota Tim)</th>
                  <th style="width:12%">Ref. Indeks KKA</th>
                  <th style="width:12%">Status Uji</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; foreach ($langkah as $l): ?>
                  <tr>
                    <td style="text-align:center;font-weight:700"><?= $no++ ?></td>
                    <td>
                      <div style="font-weight:700;color:#0f172a"><?= e($l['bidang_nama']) ?></div>
                      <span class="badge" style="background:#f1f5f9;color:#475569;font-size:10.5px;margin-top:2px"><?= e($l['bidang_kode']) ?></span>
                    </td>
                    <td>
                      <div style="font-size:12px;line-height:1.4"><?= e($l['uraian_prosedur']) ?></div>
                      <?php if (!empty($l['tujuan_pengujian'])): ?>
                        <div style="font-size:11px;color:#0369a1;margin-top:3px"><b>Tujuan:</b> <?= e($l['tujuan_pengujian']) ?></div>
                      <?php endif; ?>
                    </td>
                    <td>
                      <!-- DROPDOWN PILIH PELAKSANA ANGGOTA 1 / ANGGOTA 2 / BERSAMA -->
                      <select name="langkah[<?= $l['id'] ?>][pelaksana_user_id]" class="form-control" style="font-size:12px;padding:6px 8px;font-weight:600">
                        <option value="">-- Pilih Pelaksana --</option>
                        <?php $agNo = 1; foreach ($anggotaList as $ag): 
                          $selected = ((int)$l['pelaksana_user_id'] === (int)$ag['id']) ? 'selected' : '';
                        ?>
                          <option value="<?= $ag['id'] ?>" <?= $selected ?>>
                            Anggota <?= $agNo++ ?>: <?= e($ag['nama']) ?>
                          </option>
                        <?php endforeach; ?>
                        <option value="0" <?= ($l['pelaksana_user_id'] === null || $l['pelaksana_user_id'] == 0) ? 'selected' : '' ?>>
                          Ketua Tim &amp; Anggota (Bersama)
                        </option>
                      </select>
                    </td>
                    <td>
                      <input type="text" name="langkah[<?= $l['id'] ?>][ref_kka_nomor]" class="form-control" value="<?= e($l['ref_kka_nomor'] ?: '') ?>" placeholder="KKA-B.X.X" style="font-size:12px;padding:6px 8px">
                    </td>
                    <td>
                      <select name="langkah[<?= $l['id'] ?>][status_pelaksanaan]" class="form-control" style="font-size:11.5px;padding:5px 6px">
                        <option value="BELUM" <?= $l['status_pelaksanaan']==='BELUM'?'selected':'' ?>>Belum Selesai</option>
                        <option value="SEDANG" <?= $l['status_pelaksanaan']==='SEDANG'?'selected':'' ?>>Sedang Berjalan</option>
                        <option value="SELESAI" <?= $l['status_pelaksanaan']==='SELESAI'?'selected':'' ?>>Selesai Teruji</option>
                      </select>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;border-top:1px solid #e2e8f0;padding-top:12px">
            <button type="submit" name="action" value="save" class="btn btn-outline">
              <i class="fa-solid fa-floppy-disk"></i> Simpan Pembagian Tugas
            </button>
            <?php if ($pka['status'] !== 'DISETUJUI'): ?>
              <button type="submit" name="action" value="ajukan" class="btn btn-primary">
                <i class="fa-solid fa-paper-plane"></i> Ajukan ke Dalnis untuk Disetujui
              </button>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </main>
</div>
<?php view('partials/foot'); ?>
